using UnityEngine;

/// <summary>
/// S'assure que nos sprites sont toujours tournes vers la camera.
/// </summary>
[RequireComponent(typeof(SpriteRenderer))]
public class Billboard : MonoBehaviour
{
    #region Fields
    [SerializeField, Tooltip("Est-ce que le sprite restera toujours perpendiculaire au sol ?")]
    private bool ignoreCameraElevation = false;
    [SerializeField, Tooltip("Pour rectifier les problemes causees par une camera perspective plutot qu'iso, inutile si le bool d'au dessus est sur false")]
    private bool perspectiveCamera = false;

    private Transform mainCamera;
    private Vector3 cameraLookDirection;
    #endregion

    #region UnityMessages
    private void Awake()
    {
        GetVariables();
    }

    private void LateUpdate()
    {
        if (ignoreCameraElevation) RotateParallel();
        else RotateToCamera();
    }
    #endregion

    #region PrivateMethodes
    private void GetVariables()
    {
        mainCamera = Camera.main.transform;
    }

    private void RotateToCamera()
    {
        cameraLookDirection = mainCamera.forward;
        transform.rotation = Quaternion.LookRotation(cameraLookDirection);
    }

    private void RotateParallel()
    {
        if (!perspectiveCamera) cameraLookDirection = transform.position - mainCamera.position;
        else cameraLookDirection = mainCamera.forward;
        cameraLookDirection.y = 0;
        transform.rotation = Quaternion.LookRotation(cameraLookDirection);
    }
    #endregion
}
