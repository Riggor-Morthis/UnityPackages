using UnityEngine;
/// <summary>
/// Permet de changer le sprite affiche selon la direction du regard de l'entite.
/// Fait pour fonctionner sans offset, donc juste 2 sprites (qui regardent vers la droite) pour 4 axes
/// </summary>
public class OffsetSpriteChanger : SpriteChangerBase
{
    #region Fields
    /// <summary>On va avoir besoin de flip des sprites souvent</summary>
    private SpriteRenderer[] spriteRenderers;

    private int currentIndex = 0;
    #endregion

    #region PrivateMethods
    protected override void GetVariables()
    {
        base.GetVariables();
        spriteRenderers = new SpriteRenderer[renderers.Length];
        for(int i = 0; i < renderers.Length; i++)
            spriteRenderers[i] = renderers[i].GetComponent<SpriteRenderer>();
    }
    protected override void ShowCorrectSprite() => ShowSprite(GetSpriteIndex(CalculateAngleToCamera()));

    /// <summary>
    /// Permet de trouver l'index du sprite renderer d'apres l'angle
    /// </summary>
    private int GetSpriteIndex(float angleToCamera)
    {
        if (angleToCamera < -90f) return 0;
        else if (angleToCamera < 0f) return 1;
        else if (angleToCamera < 90f) return 2;
        return 3;
    }

    private void ShowSprite(int newIndex)
    {
        if (currentIndex != newIndex)
        {
            currentIndex = newIndex;

            switch (newIndex)
            {
                default:
                case 0:
                    renderers[0].SetActive(false);
                    renderers[1].SetActive(true);
                    spriteRenderers[1].flipX = true;
                    break;
                case 1:
                    renderers[1].SetActive(false);
                    renderers[0].SetActive(true);
                    spriteRenderers[0].flipX = true;
                    break;
                case 2:
                    renderers[1].SetActive(false);
                    renderers[0].SetActive(true);
                    spriteRenderers[0].flipX = false;
                    break;
                case 3:
                    renderers[0].SetActive(false);
                    renderers[1].SetActive(true);
                    spriteRenderers[1].flipX = false;
                    break;
            }
        }
    }
    #endregion
}
