using UnityEngine;

/// <summary>
/// Apporte les calculs necessaires pour les Sprite Changers
/// </summary>
public abstract class SpriteChangerBase : MonoBehaviour
{
    #region Fields
    [SerializeField, Tooltip("Devant - Derriere - Droite (si pas offset) - Gauche (optionnel)")]
    protected GameObject[] renderers;

    private Transform mainCamera;
    /// <summary>Les vecteurs qu'on compare</summary>
    private Vector3 vectorToCamera, standardizedForward;
    #endregion

    #region UnityMessages
    private void Awake()
    {
        GetVariables();
        HideAllSprites();
        ShowCorrectSprite();
    }

    private void LateUpdate()
    {
        ShowCorrectSprite();
    }
    #endregion

    #region PrivateMethods
    protected abstract void ShowCorrectSprite();

    protected virtual void GetVariables()
    {
        mainCamera = Camera.main.transform;
    }

    /// <summary>
    /// On calcule l'angle entre nous et la camera. Ne prend juste en compte la rotation de la camera, mais aussi sa position relativement a nous
    /// </summary>
    /// <returns></returns>
    protected float CalculateAngleToCamera()
    {
        vectorToCamera = (transform.forward - mainCamera.position).normalized;
        standardizedForward = transform.forward;

        vectorToCamera.y = 0;
        standardizedForward.y = 0;

        return (Vector3.SignedAngle(standardizedForward, vectorToCamera, Vector3.up));
    }

    /// <summary>
    /// Permet d'etre sur que tous les sprites ne sont pas affiches, pour partir sur une bonne base
    /// </summary>
    private void HideAllSprites()
    {
        foreach (GameObject renderer in renderers) renderer.SetActive(false);
        renderers[0].SetActive(true);
    }
    #endregion
}
