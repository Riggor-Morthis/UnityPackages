/// <summary>
/// Permet de changer le sprite affiche selon la direction du regard de l'entite.
/// Fait pour fonctionner sans offset, donc haut-bas-gauche-droite facon isometrique
/// </summary>
public class StraightSpriteChanger : SpriteChangerBase
{
    #region Fields
    /// <summary>Est-ce que les sprites gauche et droite sont identiques ou est-ce qu'ils faut faire la difference ?</summary>
    private bool isSpriteSymetrical;

    private int currentIndex = 0;
    #endregion

    #region PrivateMethods
    protected override void GetVariables()
    {
        base.GetVariables();
        isSpriteSymetrical = renderers.Length == 3;
    }

    protected override void ShowCorrectSprite() => ShowSprite(GetSpriteIndex(
                CalculateAngleToCamera()));

    /// <summary>
    /// Permet de trouver l'index du sprite renderer d'apres l'angle
    /// </summary>
    private int GetSpriteIndex(float angleToCamera)
    {
        if (angleToCamera < -135f) return 1;
        else if (angleToCamera < -45f) return 2;
        else if (angleToCamera < 45f) return 0;
        else if (angleToCamera < 135f) return isSpriteSymetrical ? 2 : 3;
        return 1;
    }

    /// <summary>
    /// Montre le sprite renderer qu'on lui demande
    /// </summary>
    private void ShowSprite(int newIndex)
    {
        if (currentIndex != newIndex)
        {
            //On affiche le bon sprite
            renderers[currentIndex].SetActive(false);
            currentIndex = newIndex;
            renderers[currentIndex].SetActive(true);
        }
    }
    #endregion
}
