using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(PlayerInput))]
public class FPSCameraController : MonoBehaviour
{
    #region Fields

    [SerializeField, Tooltip("Le transform de notre camera, pour les mouvements verticaux")]
    private Transform cameraPivot;

    [Space]

    [SerializeField, Tooltip("A quel vitesse on bouge notre \"Tete \"")]
    private float lookSpeed = .1f;
    [SerializeField, Range(0, 90), Tooltip("L'angle maximal que peut prendre notre camera")]
    private int maxVerticalCameraAngle = 80;

    /// <summary>Les angles de rotation actuels de notre camera, donc on a besoin de garder trace en permanence</summary>
    private float currentXRotation = 0, currentYRotation = 0;
    /// <summary>Egalise les mesures de la souris entre x et y</summary>
    private float aspectRatio;
    #endregion

    #region UnityMessages
    private void Awake()
    {
        SetUpVariables();
    }
    #endregion

    #region PublicMethods
    public void OnLook(InputValue inputValue)
    {
        CalculateNewRotations(inputValue.Get<Vector2>());
        ApplyRotations();
    }
    #endregion

    #region PrivateMethods
    private void SetUpVariables()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        aspectRatio = (float)Screen.width / Screen.height;
    }

    /// <summary>
    /// Calcul les nouveaux angles perso/camera
    /// </summary>
    private void CalculateNewRotations(Vector2 delta)
    {
        currentYRotation += delta.x * lookSpeed;
        currentXRotation = Mathf.Clamp(currentXRotation - delta.y * lookSpeed * aspectRatio,
            -maxVerticalCameraAngle, maxVerticalCameraAngle);
    }

    /// <summary>
    /// Applique nos angles de rotation a notre perso/camera
    /// </summary>
    private void ApplyRotations()
    {
        transform.localEulerAngles = new Vector3(transform.localEulerAngles.x,
            currentYRotation, transform.localEulerAngles.z);
        cameraPivot.localEulerAngles = new Vector3(currentXRotation,
            cameraPivot.localEulerAngles.y, cameraPivot.localEulerAngles.z);
    }
    #endregion
}
