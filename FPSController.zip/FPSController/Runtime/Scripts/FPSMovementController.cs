using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(PlayerInput), typeof(Rigidbody), typeof(CapsuleCollider))]
public class FPSMovementController : MonoBehaviour
{
    #region Constants
    private const float BUFFER_DURATION = .3f;
    #endregion

    #region SerializeFields
    [SerializeField, Tooltip("Notre detecteur de sol")]
    private LayerBasedCollisionDetection feet;
    [SerializeField, Tooltip("Notre detecteur de tete")]
    private RayCapableLBCD head;

    [Space]

    [SerializeField, Tooltip("La hauter du perso lorsqu'il est debout")]
    private float stangingHeight = 2f;
    [SerializeField, Tooltip("La hauter du perso lorsqu'il est accroupi")]
    private float crouchingHeight = 1.5f;

    [Space]

    [SerializeField, Tooltip("La vitesse du personnage au sol ET sans sprinter")]
    private float groundWalkingSpeed = 5f;
    [SerializeField, Tooltip("La vitesse du personnage au sol ET en sprintant")]
    private float groundRunningSpeed = 8f;
    [SerializeField, Tooltip("La vitesse du personnage au sol ET en etant accroupi")]
    private float groundCrouchingSpeed = 3f;

    [Space]

    [SerializeField, Tooltip("La vitesse du personnage en l'air ET sans sprinter")]
    private float airWalkingSpeed = 2f;
    [SerializeField, Tooltip("La vitesse du personnage en l'air ET en sprintant")]
    private float airRunningSpeed = 4f;
    [SerializeField, Tooltip("La vitesse du personnage en l'air ET en etant accroupi")]
    private float airCrouchingSpeed = 1f;

    [Space]

    [SerializeField, Tooltip("Quel distance on est sense prendre durant un saut")]
    private float jumpStrength = 3f;
    [SerializeField, Tooltip("Premier moment de la gravite, lorsqu'on est encore en ascension")]
    private float slowGravity = -2f;
    [SerializeField, Tooltip("Second moment de la gravite, pour commencer a remener au sol")]
    private float mediumGravity = -3f;
    [SerializeField, Tooltip("Dernier moment de la gravite, pour vraiment plaquer au sol")]
    private float heavyGravity = -5f;

    #endregion

    #region Fields
    private Rigidbody playerRigidbody;
    private CapsuleCollider capsuleCollider;

    /// <summary>Collisions</summary>
    private bool isGrounded, isBonked, canUncrouch;

    /// <summary>Stocker les intervalles de temps depuis certaines actions pour que ca soit plus smooth</summary>
    private float groundContactBuffer, jumpInputBuffer;

    /// <summary>Input de crouch/sprint</summary>
    private bool crouchInput, sprintInput;
    /// <summary>Etat de l'accroupissement</summary>
    private bool isCrouched;

    /// <summary>Direction de mouvement</summary>
    private Vector2 currentMovementDirection;
    /// <summary>Magnitude de notre deplacement selon X et Z</summary>
    private float currentMovementSpeed;
    /// <summary>Magnitude de notre deplacement selon Y</summary>
    private float currentGravityStrength;
    #endregion

    #region UnityMessages
    private void Awake()
    {
        GetComponents();
        ChangePlayerHeight(false);
    }

    private void FixedUpdate()
    {
        UpdateBuffers();
        UpdateCollisions();
        UpdateGravities();

        UpdateMovementState();

        ApplyPlayerMovement();
    }
    #endregion

    #region PublicMethods
    public void OnMovement(InputValue inputValue)
    {
        currentMovementDirection = inputValue.Get<Vector2>();
        if (currentMovementDirection.magnitude > 1) currentMovementDirection.Normalize();
    }

    public void OnJump(InputValue inputValue)
    {
        if (inputValue.Get<float>() > .5f) jumpInputBuffer = BUFFER_DURATION;
    }

    public void OnSprint(InputValue inputValue) => sprintInput = inputValue.Get<float>() > .5f;

    public void OnCrouch(InputValue inputValue) => crouchInput = inputValue.Get<float>() > .5f;
    #endregion

    #region PrivateMethods
    private void GetComponents()
    {
        playerRigidbody = GetComponent<Rigidbody>();
        capsuleCollider = GetComponent<CapsuleCollider>();
    }

    /// <summary>
    /// Fait descendre peu a peu les buffers
    /// </summary>
    private void UpdateBuffers()
    {
        if (groundContactBuffer > 0) groundContactBuffer -= Time.deltaTime;
        if (jumpInputBuffer > 0) jumpInputBuffer -= Time.deltaTime;
    }

    /// <summary>
    /// Est-ce qu'on touche avec la tete ou avec les pieds ?
    /// </summary>
    private void UpdateCollisions()
    {
        if (isGrounded = feet.IsColliding()) groundContactBuffer = BUFFER_DURATION;
        isBonked = head.IsColliding();
        canUncrouch = !head.CollideWithRay(.52f);
    }

    /// <summary>
    /// Rapproche le joueur du sol si on est en l'air
    /// </summary>
    private void UpdateGravities()
    {
        if (isGrounded && !Mathf.Approximately(currentGravityStrength, jumpStrength))
            currentGravityStrength = 0;
        else if (isBonked && playerRigidbody.velocity.y > 0)
            currentGravityStrength = 0;
        else
        {
            if (playerRigidbody.velocity.y > 0) currentGravityStrength += slowGravity * Time.fixedDeltaTime;
            else if (playerRigidbody.velocity.y > -2 * jumpStrength) currentGravityStrength += mediumGravity * Time.fixedDeltaTime;
            else currentGravityStrength += heavyGravity * Time.deltaTime;
        }
    }

    /// <summary>
    /// Check et assigne les variables de mouvement
    /// </summary>
    private void UpdateMovementState()
    {
        CheckCrouchStatus();
        CheckJumpStatus();
        CheckSpeedStatus();
    }

    private void CheckCrouchStatus()
    {
        if (crouchInput && !isCrouched) ChangePlayerHeight(true);
        else if (isCrouched && (!crouchInput || sprintInput))
        {
            if (canUncrouch) ChangePlayerHeight(false);
        }
    }

    /// <summary>
    /// Permet de changer la taille du joueur (hitbox, cam...)
    /// </summary>
    /// <param name="crouching">True pour etre accroupi, false pour etre debout</param>
    private void ChangePlayerHeight(bool crouching)
    {
        isCrouched = crouching;

        capsuleCollider.height = crouching ? crouchingHeight : stangingHeight;
        capsuleCollider.center = Vector3.up * (crouching ? crouchingHeight / 2f : stangingHeight / 2f);
        head.transform.localPosition = Vector3.up * (crouching ? crouchingHeight : stangingHeight);
    }

    /// <summary>
    /// Permet d'activer le saut pour le joueur
    /// </summary>
    private void CheckJumpStatus()
    {
        if (groundContactBuffer > 0 && jumpInputBuffer > 0)
        {
            groundContactBuffer = 0;
            jumpInputBuffer = 0;
            currentGravityStrength = jumpStrength;
        }
    }

    /// <summary>
    /// Change la vitesse du joueur selon ses variables de mouvement
    /// </summary>
    private void CheckSpeedStatus()
    {
        if (isGrounded)
        {
            if (isCrouched) currentMovementSpeed = groundCrouchingSpeed;
            else if (sprintInput) currentMovementSpeed = groundRunningSpeed;
            else currentMovementSpeed = groundWalkingSpeed;
        }
        else
        {
            if (isCrouched) currentMovementSpeed = airCrouchingSpeed;
            else if (sprintInput) currentMovementSpeed = airRunningSpeed;
            else currentMovementSpeed = airWalkingSpeed;
        }
    }

    /// <summary>
    /// Applique les valeurs du mouvement personnage au... personnage
    /// </summary>
    private void ApplyPlayerMovement()
    {
        playerRigidbody.velocity = transform.forward * currentMovementDirection.y * currentMovementSpeed +
            transform.right * currentMovementDirection.x * currentMovementSpeed + Vector3.up * currentGravityStrength;
    }
    #endregion
}
