using UnityEngine;

public class RayCapableLBCD : LayerBasedCollisionDetection
{
    #region PublicMethods
    public bool CollideWithRay(float detectionLength) => Physics.Raycast(transform.position, Vector3.up, detectionLength, detectableLayers);
    #endregion
}
