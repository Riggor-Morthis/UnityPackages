namespace Overworld.Usage
{
    using UnityEngine;
    using UnityEngine.InputSystem;

    public class CameraPivot : MonoBehaviour
    {
        #region Variables
        /// <summary>Est-ce qu'on est actuellement en train de bouger la camera</summary>
        private bool isPanning = false;
        /// <summary>La longueur du mouvement de camera qu'on veut</summary>
        private float panLength;
        #endregion

        #region UnityMessages
        private void Awake()
        {
            SetCursorState(false);
        }

        private void Update()
        {
            HorizontalCameraPan();
        }
        #endregion

        #region PublicMethods
        public void OnRightClick(InputValue iv) => SetCursorState(iv.Get<float>() > 0);
        public void OnCameraPan(InputValue iv) => panLength = iv.Get<float>();
        #endregion

        #region PrivateMethods
        /// <summary>
        /// Assure le changement d'etat du curseur selon l'utilisation actuelle de la carte
        /// </summary>
        /// <param name="pan"></param>
        private void SetCursorState(bool pan)
        {
            isPanning = pan;
            Cursor.visible = !pan;

            if (!pan)
            {
                Cursor.lockState = CursorLockMode.Confined;
            }
            else
            {
                Cursor.lockState = CursorLockMode.Locked;
            }
        }

        /// <summary>
        /// Applique la rotation de camera demandee par l'utilisateur
        /// </summary>
        private void HorizontalCameraPan()
        {
            if (isPanning)
            {
                transform.eulerAngles += Vector3.up * panLength;
            }
        }
        #endregion
    }
}