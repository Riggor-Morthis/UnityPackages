namespace Overworld.Visuals
{
    using UnityEngine;

    [RequireComponent(typeof(MeshFilter), typeof(MeshCollider))]
    public class MapTile : MonoBehaviour
    {
        #region PublicMethods
        /// <summary>
        /// Place la tuile a bon endroit dans le monde, et l'incline comme necessaire
        /// </summary>
        /// <param name="xPosition">La position en X</param>
        /// <param name="zPosition">La position en Y</param>
        /// <param name="yPositions">Les 4 sommets de la tuile, pour l'inclination correcte</param>
        public void SetWorldPosition(float xPosition, float zPosition, float[] yPositions)
        {
            Mesh mesh = new Mesh() { name = "tileMesh" };

            Vector3[] newVertices = {new Vector3(xPosition, yPositions[0], zPosition),
                new Vector3(xPosition + 1, yPositions[1], zPosition),
                new Vector3(xPosition, yPositions[2], zPosition + 1),
                new Vector3(xPosition + 1, yPositions[3], zPosition +1)};


            Vector3[] newNormals = new Vector3[4];
            for (int index = 0; index < 4; index++)
            {
                newNormals[index] = Vector3.up;
            }

            int[] newTriangles = { 0, 3, 1, 3, 0, 2 };
            Vector2[] newUV = { new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 1), new Vector2(1, 1) };
            Vector4[] newTangents = { new Vector4(1, 0, 0, -1), new Vector4(1, 0, 0, -1),
                new Vector4(1, 0, 0, -1), new Vector4(1, 0, 0, -1) };

            mesh.vertices = newVertices;
            mesh.normals = newNormals;
            mesh.triangles = newTriangles;
            mesh.uv = newUV;
            mesh.tangents = newTangents;

            GetComponent<MeshFilter>().mesh = mesh;
            GetComponent<MeshCollider>().sharedMesh = mesh;
        }

        /// <summary>
        /// Change la couleur de notre texture
        /// </summary>
        public void SetColour(Color col)
        {
            GetComponent<MeshRenderer>().material.color = col;
        }
        #endregion
    }
}