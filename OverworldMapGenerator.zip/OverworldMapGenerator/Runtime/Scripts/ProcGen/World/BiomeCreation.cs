namespace ProcGen.World
{
    using System.Collections.Generic;
    using UnityEngine;

    public static class BiomeCreation
    {
        #region Variables
        /// <summary>Les infos sur nos tuiles, qu'on veut renvoyer a la fin</summary>
        private static Vector3[,] tileBiome;

        private static float[,] vertexCoordinates;
        #endregion

        #region PublicMethods
        /// <summary>
        /// Calcule la hauteur, l'humidite et la temperature de chaque tuile
        /// </summary>
        /// <param name="vertexCoordinates">Les coordonnees en Y comme point de depart</param>
        /// <param name="tileBiome">Les informations ecologiques de chaque tuile</param>
        public static Vector3[,] CalculateBiomes(float[,] vC)
        {
            tileBiome = new Vector3[vC.GetLength(0) - 1, vC.GetLength(1) - 1];
            vertexCoordinates = vC;

            CalculateElevation();
            CalculateHumidity();
            CalculateTemperature();

            return tileBiome;
        }
        #endregion

        #region PrivateMethods
        /// <summary>
        /// Permet d'estimer vaguement le type d'altitude de l'endroit
        /// </summary>
        private static void CalculateElevation()
        {
            //Premiere passe pour trouver le point le plus haut (on sait que le minimum est a 0)
            float max = 0;
            foreach (float vertex in vertexCoordinates)
            {
                if (vertex > max)
                {
                    max = vertex;
                }
            }

            ApplyElevation(max);
        }

        /// <summary>
        /// Affecte de l'humidite aux points bas, et la repend aux points environants
        /// </summary>
        private static void CalculateHumidity()
        {
            //Les coordonnees a faire, les coordonnes faites
            List<Vector3> toDo = new(), done = new();

            //Premiere passe : on recupere toutes les tuiles avec une altitude de 0
            for (int x = 0; x < tileBiome.GetLength(0); x++)
            {
                for (int y = 0; y < tileBiome.GetLength(1); y++)
                {
                    if (tileBiome[x, y].x == 0)
                    {
                        toDo.Add(new Vector3(x, y, 1));
                    }
                }
            }

            Vector3 currentTile;
            //Seconde passe : tant qu'on a des tuiles a faire, on les fait
            while (toDo.Count > 0)
            {
                //Recuperation de la tuile
                currentTile = toDo[0];
                HumidityMainLoopOperation(currentTile, ref toDo, ref done);
                toDo.RemoveAt(0);
            }
        }

        /// <summary>
        /// Assigne aleatoirement des temperatures aux tuiles, avec le froid en bas et le chaud en haut
        /// </summary>
        private static void CalculateTemperature()
        {
            //On en aura besoin pour forcer l'aleatoire
            float heatRdm = .5f, coldRdm = .5f;

            //On trouve les lignes de separation
            int coldLine = (int)(tileBiome.GetLength(1) / 3f)
                + Random.Range(-1, 2);
            int heatLine = (int)(tileBiome.GetLength(1) / 3f * 2f)
                + Random.Range(-1, 2);

            for (int x = 0; x < tileBiome.GetLength(0); x++)
            {
                //On bouge aleatoirement la separation
                EvolveTheTemperatureLine(ref heatRdm, ref heatLine);
                EvolveTheTemperatureLine(ref coldRdm, ref coldLine);

                //On affecte la valeur de temperature en fonction de ces separations
                for (int y = coldLine; y <= heatLine; y++)
                {
                    tileBiome[x, y] += Vector3.forward * .5f;
                }
                for (int y = heatLine + 1; y < tileBiome.GetLength(1); y++)
                {
                    tileBiome[x, y] += Vector3.forward * 1f;
                }
            }
        }

        /// <summary>
        /// Assure l'attribution d'humidite en fonction des tuiles environnates
        /// </summary>
        private static void HumidityMainLoopOperation(Vector3 currentTile,
            ref List<Vector3> toDo, ref List<Vector3> done)
        {
            //On s'ignore si on est pas dans la matrice
            if(currentTile.x >= 0 && currentTile.x < tileBiome.GetLength(0))
            {
                if (currentTile.y >= 0 && currentTile.y < tileBiome.GetLength(1))
                {
                    //Si on essaye de nous refiler une tuile plus seche, on fait rien
                    if (currentTile.z > tileBiome[(int)currentTile.x, (int)currentTile.y].z)
                    {
                        //On commence par l'attribution de valeur
                        tileBiome[(int)currentTile.x, (int)currentTile.y]
                            = new Vector3(tileBiome[(int)currentTile.x, (int)currentTile.y].x, currentTile.z, 0f);
                        done.Add(currentTile);

                        //Maintenant, on cherche parmis ses voisinnes si il y a en d'autres a faire
                        //On s'arrete si on est deja plutot seche
                        if (currentTile.z > .2f)
                        {
                            Vector3 tempVector;
                            tempVector = new Vector3(currentTile.x - 1, currentTile.y, currentTile.z - .2f);
                            if (!toDo.Contains(tempVector) && !done.Contains(tempVector))
                            {
                                toDo.Add(tempVector);
                            }

                            tempVector = new Vector3(currentTile.x + 1, currentTile.y, currentTile.z - .2f);
                            if (!toDo.Contains(tempVector) && !done.Contains(tempVector))
                            {
                                toDo.Add(tempVector);
                            }

                            tempVector = new Vector3(currentTile.x, currentTile.y - 1, currentTile.z - .2f);
                            if (!toDo.Contains(tempVector) && !done.Contains(tempVector))
                            {
                                toDo.Add(tempVector);
                            }

                            tempVector = new Vector3(currentTile.x, currentTile.y + 1, currentTile.z - .2f);
                            if (!toDo.Contains(tempVector) && !done.Contains(tempVector))
                            {
                                toDo.Add(tempVector);
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Change le type de biome en fonction du point maximal calcule
        /// </summary>
        /// <param name="max"></param>
        private static void ApplyElevation(float max)
        {
            //On a donc deux caps (eau et sommet) pour nos infos d'altitude
            float waterCap = max * .01f;
            float peakCap = max * .9f;
            float avg;
            for (int x = 0; x < tileBiome.GetLength(0); x++)
            {
                for (int y = 0; y < tileBiome.GetLength(1); y++)
                {
                    avg = (vertexCoordinates[x, y] + vertexCoordinates[x + 1, y] +
                        vertexCoordinates[x, y + 1] + vertexCoordinates[x + 1, y + 1]) / 4f;
                    if (avg <= waterCap)
                    {
                        tileBiome[x, y] = new Vector3(0, 0, 0);
                    }
                    else if (avg >= peakCap)
                    {
                        tileBiome[x, y] = new Vector3(1, 0, 0);
                    }
                    else
                    {
                        tileBiome[x, y] = new Vector3(.5f, 0, 0);
                    }
                }
            }
        }

        /// <summary>
        /// Change aleatoirement la temperature dans une direction aleatoire
        /// </summary>
        private static void EvolveTheTemperatureLine(ref float rdm, ref int line)
        {
            if (Random.Range(0f, 1f) <= rdm)
            {
                rdm = 0;
                line += (int)Mathf.Sign(Random.Range(-1, 1));
                line = (int)Mathf.Clamp(line, 0f, tileBiome.GetLength(1));
            }
            else
            {
                rdm += .2f;
            }
        }
        #endregion
    }
}