namespace ProcGen.World
{
    using Overworld.Visuals;
    using UnityEngine;

    public class GenerationHandler : MonoBehaviour
    {
        #region SerializeFields
        [SerializeField, Tooltip("Le composant visuel de notre carte")]
        private GameObject mapTile;

        [Space]

        [SerializeField]
        private Color coldWater;
        [SerializeField]
        private Color mildWater;
        [SerializeField]
        private Color hotWater;

        [Space]

        [SerializeField]
        private Color mountainPeak;

        [Space]
        [SerializeField]
        private Color desert;
        [SerializeField]
        private Color savanah;
        [SerializeField]
        private Color jungle;

        [Space]
        [SerializeField]
        private Color plain;
        [SerializeField]
        private Color forest;

        [Space]
        [SerializeField]
        private Color tundra;
        [SerializeField]
        private Color taiga;
        [SerializeField]
        private Color ice;
        #endregion

        #region UnityMessages
        private void Awake()
        {
            Color[] tileColors = new Color[]{coldWater, mildWater, hotWater, mountainPeak, desert, savanah, jungle,
            plain, forest, tundra, taiga, ice};

            float[,] vertexCoordinates = RoughLandscape.GenerateLandscape(61, 31);

            Vector3[,] tileBiome = BiomeCreation.CalculateBiomes(vertexCoordinates);

            MapTile[,] generatedTiles = TilePlacement.CreateTheTiles(vertexCoordinates, tileBiome, mapTile,
                transform, tileColors);
        }
        #endregion
    }
}