namespace ProcGen.World
{
    using System.Collections.Generic;
    using UnityEngine;

    public static class RoughLandscape
    {
        #region Variables
        /// <summary>Les coordonnes verticales de la carte determinees par un bruit</summary>
        private static float[,] vertexCoordinates;
        #endregion

        #region PublicMethods
        /// <summary>
        /// Genere l'allure generale de la carte
        /// </summary>
        /// <param name="vertexCoordinates">Tous les coordonnees en Y qu'on va utiliser</param>
        public static float[,] GenerateLandscape(int xLength, int yLength)
        {
            //On veut une grille de 32x32 tuiles pour l'overworld
            //Donc il faut 33x33 float pour les vertex
            vertexCoordinates = new float[xLength, yLength];

            GeneratePureMountains();
            GenerateBodiesWater();

            return vertexCoordinates;
        }
        #endregion

        #region PrivateMethods/// <summary>
        /// Pour generer les reliefs generaux initiaux
        /// </summary>
        private static void GeneratePureMountains()
        {
            //On prend comme seed l'heure actuelle en seconde unix, pour la rejouabilite
            float seed = ((System.DateTimeOffset)System.DateTime.Now).ToUnixTimeSeconds();

            //Premier harmonique (hauteur x 8, coord +1)
            Harmonics(seed, 0);
            //Second harmonique (hauteur x 4, coord +2)
            Harmonics(seed, 1);
            //Troisieme harmonique (hauteur x 2, coord +4)
            Harmonics(seed, 2);
            //Quatrieme harmonique (hauteur x 1, coord +8)
            Harmonics(seed, 3);

            //On embellit
            SetToZero();
            Normalize();
        }

        /// <summary>
        /// Gere les differentes etapes necessaires pour creer des zones d'eau
        /// </summary>
        private static void GenerateBodiesWater()
        {
            float[,] erosionMatrix = GenerateErosionMatrix();
            erosionMatrix = SpreadErosionMatrix(erosionMatrix);
            ApplyErosionMatrix(erosionMatrix);
        }



        /// <summary>
        /// Permet d'appliquer du terrain selon le principe d'octave
        /// </summary>
        /// <param name="seed">Seed pour l'aleatoire</param>
        /// <param name="harmonic">Le nombre de l'octave, DOIT ETRE ENTRE 0 ET 3</param>
        /// <param name="vertexCoordinates">Le tableau de reference pour acceuillir les valeurs de bruit</param>
        private static void Harmonics(float seed, int harmonic)
        {
            //La d'ou on part
            float coordX = Random.Range(-seed, seed) % 1000f;
            float coordY = Random.Range(-seed, seed) % 1000f;

            //La multiplication des valeurs et la distance "traversee"
            int multiplier = (int)Mathf.Pow(2, 3 - harmonic);
            int offset = (int)Mathf.Pow(2, harmonic);

            //Stockage
            float pNoise;

            for (int x = 0; x < vertexCoordinates.GetLength(0); x++)
            {
                for (int y = 0; y < vertexCoordinates.GetLength(1); y++)
                {
                    pNoise = Mathf.PerlinNoise(
                        coordX + (float)x / (vertexCoordinates.GetLength(0) - 1) * offset,
                        coordY + (float)y / (vertexCoordinates.GetLength(1) - 1) * offset);

                    vertexCoordinates[x, y] += pNoise * multiplier;
                }
            }
        }

        /// <summary>
        /// Permet de s'assurer que le vertex le plus bas est en y = 0
        /// </summary>
        private static void SetToZero()
        {
            //On trouve le point le plus bas
            float min = 1000;
            foreach (float coordinates in vertexCoordinates)
            {
                if (min > coordinates)
                {
                    min = coordinates;
                }
            }

            //On ramene tout le monde plus bas
            for (int x = 0; x < vertexCoordinates.GetLength(0); x++)
            {
                for (int y = 0; y < vertexCoordinates.GetLength(1); y++)
                {
                    vertexCoordinates[x, y] -= min;
                }
            }
        }

        /// <summary>
        /// Ramene tout entre 0 et 1
        /// </summary>
        private static void Normalize()
        {
            //On trouve le point le plus bas
            float max = 0;
            foreach (float coordinates in vertexCoordinates)
            {
                if (max < coordinates)
                {
                    max = coordinates;
                }
            }

            //On ramene tout le monde plus bas
            for (int x = 0; x < vertexCoordinates.GetLength(0); x++)
            {
                for (int y = 0; y < vertexCoordinates.GetLength(1); y++)
                {
                    vertexCoordinates[x, y] /= max;
                }
            }
        }

        /// <summary>
        /// Permet de generer une matrice qui va forcer les vertex proches de l'eau a se rabaisser
        /// </summary>
        private static float[,] GenerateErosionMatrix()
        {
            //Malheureusement, on a besoin d'initialiser la matrice a 1
            float[,] erosionMatrix = new float[vertexCoordinates.GetLength(0), vertexCoordinates.GetLength(1)];
            for (int x = 0; x < erosionMatrix.GetLength(0); x++)
            {
                for (int y = 0; y < erosionMatrix.GetLength(1); y++)
                {
                    erosionMatrix[x, y] = 1f;
                }
            }

            //On genere la mer a l'ouest et a l'est
            for (int offset = 0; offset < 3; offset++)
            {
                for (int y = offset; y < vertexCoordinates.GetLength(1) - offset; y++)
                {
                    erosionMatrix[offset, y] = 0;
                    erosionMatrix[vertexCoordinates.GetLength(0) - offset - 1, y] = 0;
                }
            }

            //On genere la mer au nord et au sud
            for (int offset = 0; offset < 3; offset++)
            {
                for (int x = offset + 1; x < vertexCoordinates.GetLength(0) - offset - 1; x++)
                {
                    erosionMatrix[x, offset] = 0;
                    erosionMatrix[x, vertexCoordinates.GetLength(1) - offset - 1] = 0;
                }
            }

            //On verifie tous les points bas de la carte pour les mettre dans la matrice
            for (int x = 0; x < vertexCoordinates.GetLength(0); x++)
            {
                for (int y = 0; y < vertexCoordinates.GetLength(1); y++)
                {
                    if (vertexCoordinates[x, y] <= .4f)
                    {
                        erosionMatrix[x, y] = 0;
                    }
                }
            }

            return erosionMatrix;
        }

        /// <summary>
        /// Prend les points a 0 et les etend sur les vertex adjacents
        /// </summary>
        private static float[,] SpreadErosionMatrix(float[,] erosionMatrix)
        {
            //X et Y sont les coordonnes dans la matrice, Z est la coordonee a mettre dans la matrice
            List<Vector3> toDo = new();
            Vector3 currentVertex;

            //On recupere les premieres infos
            for (int x = 0; x < erosionMatrix.GetLength(0); x++)
            {
                for (int y = 0; y < erosionMatrix.GetLength(1); y++)
                {
                    if (erosionMatrix[x, y] == 0)
                    {
                        toDo.Add(new Vector3(x, y, 0));
                    }
                }
            }

            //On fait tant qu'il nous reste des vertex a affecter
            while (toDo.Count > 0)
            {
                currentVertex = toDo[0];
                ErosionMatrixMainOperation(currentVertex, ref erosionMatrix, ref toDo);
                toDo.RemoveAt(0);
            }

            return erosionMatrix;
        }

        /// <summary>
        /// Combine la matrice d'altitude avec la matrice d'erosion
        /// </summary>
        private static void ApplyErosionMatrix(float[,] erosionMatrix)
        {
            for (int x = 0; x < erosionMatrix.GetLength(0); x++)
            {
                for (int y = 0; y < erosionMatrix.GetLength(1); y++)
                {
                    vertexCoordinates[x, y] *= erosionMatrix[x, y];
                }
            }

            //Pour etre sur, on re-normalise, puis on embellit
            Normalize();
            Accentuate();
        }

        /// <summary>
        /// Permet d'etendre notre erosion aux voisins valides
        /// </summary>
        private static void ErosionMatrixMainOperation(Vector3 currentVertex, ref float[,] erosionMatrix,
            ref List<Vector3> toDo)
        {
            //On ignore les coordonnees invalides
            if (currentVertex.x >= 0 && currentVertex.x < erosionMatrix.GetLength(0))
            {
                if (currentVertex.y >= 0 && currentVertex.y < erosionMatrix.GetLength(1))
                {
                    //On ignore si on est deja plus petit
                    if (currentVertex.z <= erosionMatrix[(int)currentVertex.x, (int)currentVertex.y])
                    {
                        erosionMatrix[(int)currentVertex.x, (int)currentVertex.y] = currentVertex.z;

                        toDo.Add(new Vector3(currentVertex.x - 1, currentVertex.y, currentVertex.z + .2f));
                        toDo.Add(new Vector3(currentVertex.x + 1, currentVertex.y, currentVertex.z + .2f));
                        toDo.Add(new Vector3(currentVertex.x, currentVertex.y - 1, currentVertex.z + .2f));
                        toDo.Add(new Vector3(currentVertex.x, currentVertex.y + 1, currentVertex.z + .2f));
                    }
                }
            }
        }

        /// <summary>
        /// Rend les plats plus plats, et les pointes plus pointues
        /// </summary>
        private static void Accentuate()
        {
            for (int x = 0; x < vertexCoordinates.GetLength(0); x++)
            {
                for (int y = 0; y < vertexCoordinates.GetLength(1); y++)
                {
                    vertexCoordinates[x, y] = (Mathf.Exp(vertexCoordinates[x, y]) - 1) * 2.5f;
                }
            }
        }
        #endregion
    }
}