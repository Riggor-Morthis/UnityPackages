namespace ProcGen.World
{
    using Overworld.Visuals;
    using UnityEngine;

    public static class TilePlacement
    {
        #region Variables
        /// <summary>Les tuiles qu'on fait ainsi apparaitre pour notre carte</summary>
        private static MapTile[,] generatedMap;

        private static float[,] vertexCoordinates;
        private static Vector3[,] tileBiome;
        #endregion

        #region PublicMethods
        /// <summary>
        /// Place les tuiles, avec une couleur valide
        /// </summary>
        public static MapTile[,] CreateTheTiles(float[,] vC, Vector3[,] tB,
            GameObject tilePrefab, Transform parentTransform, Color[] tileColors)
        {
            generatedMap = new MapTile[tB.GetLength(0), tB.GetLength(1)];
            vertexCoordinates = vC;
            tileBiome = tB;

            TilePlacer(tilePrefab, parentTransform, tileColors);

            return generatedMap;
        }
        #endregion

        #region PrivateMethods
        /// <summary>
        /// Place automatiquement les differentes tuiles qui composent donc notre carte
        /// </summary>
        private static void TilePlacer(GameObject tilePrefab, Transform parentTransform, Color[] tileColors)
        {
            //Pour centrer la carte pour la camera
            float xCenterOffset = vertexCoordinates.GetLength(0) / 2f;
            float zCenterOffset = vertexCoordinates.GetLength(1) / 2f;

            //On fait le tour de tous les vertex, et on creer les tuiles appropriees
            MapTile currentTile;
            for (int x = 0; x < generatedMap.GetLength(0); x++)
            {
                for (int y = 0; y < generatedMap.GetLength(1); y++)
                {
                    //On commence par juste poser la tuile, et la mettre a la bonne place
                    currentTile = GameObject.Instantiate(tilePrefab, parentTransform).GetComponent<MapTile>();
                    currentTile.SetWorldPosition(x - xCenterOffset, y - zCenterOffset,
                        new float[] { vertexCoordinates[x, y], vertexCoordinates[x + 1, y],
                        vertexCoordinates[x, y +1], vertexCoordinates[x+1, y+1]});

                    //On lui donne sa bonne couleur
                    TileColorer(currentTile, tileBiome[x, y], tileColors);
                }
            }
        }

        /// <summary>
        /// Attribut la couleur correct d'une tuile en fonction de ses circonstances
        /// </summary>
        private static void TileColorer(MapTile currentTile, Vector3 biome, Color[] tileColors)
        {
            switch (biome.x)
            {
                //Cas ou c'est juste de l'eau
                default:
                case 0:
                    WaterColoration(currentTile, biome, tileColors);
                    break;

                //Cas oppose ou c'est juste du sommet
                case 1:
                    currentTile.SetColour(tileColors[3]);
                    break;

                //Maintenant on a le detail
                case .5f:
                    MainTerrainColoration(currentTile, biome, tileColors);
                    break;
            };
        }

        /// <summary>
        /// Pour colorer les tuiles d'eau
        /// </summary>
        private static void WaterColoration(MapTile currentTile, Vector3 biome, Color[] tileColors)
        {
            switch (biome.z)
            {
                default:
                case 0:
                    currentTile.SetColour(tileColors[0]);
                    break;
                case .5f:
                    currentTile.SetColour(tileColors[1]);
                    break;
                case 1:
                    currentTile.SetColour(tileColors[2]);
                    break;
            }
        }

        private static void MainTerrainColoration(MapTile currentTile, Vector3 biome, Color[] tileColors)
        {
            //Temperatues chaudes
            if (biome.z == 1)
            {
                if (biome.y == 0)
                {
                    currentTile.SetColour(tileColors[4]);
                }
                else if (biome.y <= .6f)
                {
                    currentTile.SetColour(tileColors[5]);
                }
                else
                {
                    currentTile.SetColour(tileColors[6]);
                }
            }

            //Temperatures temperees
            else if (biome.z == .5f)
            {
                if (biome.y <= .4f)
                {
                    currentTile.SetColour(tileColors[7]);
                }
                else
                {
                    currentTile.SetColour(tileColors[8]);
                }
            }

            //Temperatures chaudes
            else
            {
                if (biome.y <= .2f)
                {
                    currentTile.SetColour(tileColors[9]);
                }
                else if (biome.y <= .6f)
                {
                    currentTile.SetColour(tileColors[10]);
                }
                else
                {
                    currentTile.SetColour(tileColors[11]);
                }
            }
        }
        #endregion
    }
}