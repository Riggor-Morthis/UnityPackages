using UnityEngine;

/// <summary>
/// Permet de set-up la taille et la couleur de l'outline
/// La taille de l'outline est dependante de la taille des pixels du sprite
/// </summary>
[RequireComponent(typeof(SpriteRenderer))]
public class SpriteOutline : MonoBehaviour
{
    #region Fields
    [SerializeField, Tooltip("L'epaisseur du trait, donne en pixels relativement aux pixels du sprite")]
    private float outlineSize = .1f;

    [SerializeField, Tooltip("La couleur du trait")]
    private Color outlineColor = Color.black;

    private SpriteRenderer spriteRenderer;
    #endregion

    #region UnityMessages
    private void Awake()
    {
        GetComponents();
        SetOutline();
    }
    #endregion

    #region PrivatMethods
    private void GetComponents()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void SetOutline()
    {
        //Recup de variables
        float sheetWidth = spriteRenderer.sprite.texture.width;
        float sheetHeight = spriteRenderer.sprite.texture.height;

        //Set-up du
        spriteRenderer.material.SetFloat("_outlineWidth", outlineSize / sheetWidth);
        spriteRenderer.material.SetFloat("_outlineHeight", outlineSize / sheetHeight);
        spriteRenderer.material.SetColor("_outlineColor", outlineColor);
    }
    #endregion
}
