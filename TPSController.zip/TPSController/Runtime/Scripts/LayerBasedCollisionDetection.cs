using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Collider))]
public class LayerBasedCollisionDetection : MonoBehaviour
{
    #region Fields
    [SerializeField, Tooltip("Les layers qu'on a besoin de detecter")]
    protected LayerMask detectableLayers;

    /// <summary>Tous les colliders qu'on est actuellement en train de detecter</summary>
    protected List<Collider> collisions = new();
    #endregion

    #region UnityMessages
    protected void OnTriggerEnter(Collider other)
    {
        GameObject otherGo = other.gameObject;
        if ((detectableLayers.value & 1 << otherGo.layer) != 0) collisions.Add(other);
    }

    protected void OnTriggerExit(Collider other)
    {
        if (collisions.Contains(other)) collisions.Remove(other);
    }
    #endregion

    #region PublicMethods
    /// <summary>
    /// Est-ce qu'on est actuellement en train de detecter une collision approprie ?
    /// </summary>
    public bool IsColliding() => collisions.Count > 0;
    #endregion
}
