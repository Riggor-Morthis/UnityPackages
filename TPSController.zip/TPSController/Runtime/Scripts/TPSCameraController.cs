using UnityEngine;
using UnityEngine.InputSystem;

public class TPSCameraController : MonoBehaviour
{
    #region Fields

    [SerializeField, Tooltip("Le transform de notre camera, pour les mouvements verticaux")]
    private Transform cameraTransform;

    [Space]

    [SerializeField, Tooltip("A quel vitesse on bouge notre \"Tete \"")]
    private float lookSpeed = .1f;
    [SerializeField, Range(0, 90), Tooltip("L'angle maximal que peut prendre notre camera")]
    private int maxVerticalCameraAngle = 80;
    [SerializeField, Range(-90, 0), Tooltip("L'angle minimal que peut prendre notre camera")]
    private int minVerticalCameraAngle = -70;
    [SerializeField, Tooltip("La distance de notre camera lorsqu'on est sur l'angle minimal")]
    private float bottomMagnitude = 1f;
    [SerializeField, Tooltip("La distance de notre camera lorsqu'on sur un angle de 0")]
    private float middleMagnitude = 5f;
    [SerializeField, Tooltip("La distance de notre camera lorsqu'on est sur l'angle maximal")]
    private float topMagnitude = 2f;

    /// <summary>Les angles de rotation actuels de notre camera, donc on a besoin de garder trace en permanence</summary>
    private float currentXRotation = 0, currentYRotation = 0;
    /// <summary>Tout un tas de variables pour nos calculs de triangles</summary>
    private float currentMagnitude = 0, currentThirdAngle = 0, currentHorizontalAxis = 0, currentVerticalAxis = 0;
    /// <summary>Egalise les mesures de la souris entre x et y</summary>
    private float aspectRatio;
    #endregion

    #region UnityMessages
    private void Awake()
    {
        SetUpVariables();
    }
    #endregion

    #region PublicMethods
    public void OnLook(InputValue inputValue)
    {
        HandleYRotation(inputValue.Get<Vector2>());
        HandleXRotation(inputValue.Get<Vector2>());
    }
    #endregion

    #region PrivateMethods
    private void SetUpVariables()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        aspectRatio = (float)Screen.width / Screen.height;
    }

    /// <summary>
    /// Gere l'angle horizontal de notre vue
    /// </summary>
    private void HandleYRotation(Vector2 delta)
    {
        currentYRotation = transform.localEulerAngles.y + delta.x * lookSpeed;
        transform.localEulerAngles = new Vector3(0, currentYRotation, 0);
    }

    /// <summary>
    /// Gere l'angle vertical de la camera + sa position via de la trigo
    /// </summary>
    /// <param name="delta"></param>
    private void HandleXRotation(Vector2 delta)
    {
        //Commence par l'angle essential
        currentXRotation = Mathf.Clamp(currentXRotation - delta.y * lookSpeed * aspectRatio,
            minVerticalCameraAngle, maxVerticalCameraAngle);

        //On calcule la magnitude selon l'angle actuel et des fausses beziers
        if(currentXRotation > 0)
        {
            currentMagnitude = (1 - (currentXRotation / maxVerticalCameraAngle)) * middleMagnitude +
                (currentXRotation / maxVerticalCameraAngle) * topMagnitude;
        }
        else
        {
            currentMagnitude = (1 - ((-currentMagnitude) / minVerticalCameraAngle)) * middleMagnitude +
                ((-currentMagnitude) / minVerticalCameraAngle) * bottomMagnitude;
        }

        //Variables via trigo
        currentThirdAngle = 180 - (90 + currentXRotation);
        currentVerticalAxis = currentMagnitude * Mathf.Sin(currentXRotation * Mathf.Deg2Rad) / Mathf.Sin(90 * Mathf.Deg2Rad);
        currentHorizontalAxis = currentMagnitude * Mathf.Sin(currentThirdAngle * Mathf.Deg2Rad) / Mathf.Sin(90 * Mathf.Deg2Rad);

        //On applique tout ca au transform de notre camera;
        cameraTransform.localEulerAngles = new Vector3(currentXRotation, 0f, 0f);
        cameraTransform.localPosition = new Vector3(0f, currentVerticalAxis, -currentHorizontalAxis);
    }
    #endregion
}
